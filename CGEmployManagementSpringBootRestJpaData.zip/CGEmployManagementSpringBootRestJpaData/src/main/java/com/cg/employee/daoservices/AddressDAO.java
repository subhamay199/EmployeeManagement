package com.cg.employee.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.employee.bean.Address;

public interface AddressDAO extends JpaRepository<Address, Integer>{

}
